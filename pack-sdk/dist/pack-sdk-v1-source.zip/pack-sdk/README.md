# Pack SDK v1

Android library source module with `ILanguagePack.aidl`, `ITaskCallback.aidl` and `PackContract.java`. Build the consuming sample with `.\build-local.ps1 -Product sample`. A third-party Gradle project can include this module or copy the AIDL and Java files under the same `org.pocketide.pack.v1` package. `python tools/package-pack-sdk.py` creates a reproducible source SDK ZIP. The protocol is documented in `docs/language-pack-api/v1/README.md`. The offline toolchain lacks `com.android.tools.lint:lint-gradle:31.13.0`, so a standalone AAR is not produced in this workspace; the module compiles as a dependency of both APKs.

The SDK contains only interfaces and constants. It does not grant SAF access, trust a pack, bundle a language runtime, or perform network requests. Source license: root MIT `LICENSE`.
